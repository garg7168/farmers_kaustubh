(function () {
    'use strict';
    angular.module('farmersApp').controller('firstviewController', ['$scope', function ($scope) {

        var vm = this;
		
    }]);
})();