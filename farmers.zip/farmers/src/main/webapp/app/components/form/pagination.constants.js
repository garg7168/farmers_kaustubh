(function() {
    'use strict';

    angular
        .module('farmersApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
