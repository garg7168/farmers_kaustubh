(function () {
    'use strict';

    angular
        .module('farmersApp')
        .config(materialDesignConfig);

    function materialDesignConfig() {
        // Initialize material design
        $.material.init();
    }
})();
