/**
 * Spring Data JPA repositories.
 */
package com.farmers.repository;
