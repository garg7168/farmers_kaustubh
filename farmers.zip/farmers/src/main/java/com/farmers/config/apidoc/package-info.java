/**
 * Swagger api specific code.
 */
package com.farmers.config.apidoc;