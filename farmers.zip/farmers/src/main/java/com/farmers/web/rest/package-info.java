/**
 * Spring MVC REST controllers.
 */
package com.farmers.web.rest;
