/**
 * JPA domain objects.
 */
package com.farmers.domain;
