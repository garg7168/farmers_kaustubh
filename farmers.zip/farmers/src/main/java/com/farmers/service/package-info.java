/**
 * Service layer beans.
 */
package com.farmers.service;
